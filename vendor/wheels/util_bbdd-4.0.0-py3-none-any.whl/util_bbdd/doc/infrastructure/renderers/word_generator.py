"""
Módulo para generación de documentación en formato Word
"""

import io
import logging

from collections.abc import Callable
from pathlib import Path
from typing import Any, cast

# Word imports
from docx import Document as load_document
from docx.document import Document
from docx.enum.section import WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.image.image import Image as DocxImage
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.section import Section
from docx.shared import Emu, Pt
from docx.table import Table, _Row
from docx.text.paragraph import Paragraph
from docx.text.run import Run

from ...._core.exceptions import DatabaseException, DocumentationConfigError
from ...._core.export_safety import safe_text
from ....analysis.graphviz_ext import GraphvizRelationshipGraphExt
from ...application.ports import DocumentationManagerPort, HeadersConfig
from ...application.use_cases.engine_conditions import EngineConditionsSectionBuilder
from .shared.diagram_legend import (
    build_diagram_legend_payload,
    build_diagram_legend_rows,
)
from .shared.diagram_summary import build_diagram_summary_line, build_diagram_summary_payload
from .shared.generator_shared import (
    GeneratorDatabaseInfoRuntime,
    GeneratorInventoryRuntime,
    GeneratorRoutineRuntime,
    GeneratorTableRuntime,
    GeneratorTabularRuntime,
    build_graph_generator_from_options,
)
from .shared.print_config_manager import PrintConfigManager


class DocumentChunkConfig:
    """Contenedor de configuración para generar un chunk de documento.

    Agrupa los parámetros booleanos y de configuración para reducir
    la complejidad de las firmas de método.
    """

    def __init__(
        self,
        include_tables: bool,
        include_views: bool,
        include_procedures: bool,
        include_functions: bool,
        include_storage: bool,
        table_section_flags: list[bool],
        view_section_flags: list[bool],
        include_diagrams: bool,
        template_path: Path | None = None,
        diagram_options: dict[str, Any] | None = None,
        include_database_info: bool = False,
        database_info_flags: list[bool] | None = None,
        include_columns_charset: bool = False,
        include_engine_conditions: bool = False,
    ) -> None:
        """Inicializa la configuración del documento.

        Args:
            include_tables: Si incluir tablas en el documento
            include_views: Si incluir vistas en el documento
            include_procedures: Si incluir procedures en el documento
            include_functions: Si incluir funciones en el documento
            include_storage: Si incluir sección de almacenamiento
            table_section_flags: Flags para secciones de tablas
            view_section_flags: Flags para secciones de vistas
            include_diagrams: Si incluir diagramas de relaciones
            template_path: Ruta opcional a plantilla Word
            diagram_options: Opciones de generación de diagramas
            include_database_info: Si incluir información de BD (versión, charset)
            database_info_flags: [version_flag, charset_collation_flag]
            include_columns_charset: Si incluir charset/collation de columnas
            include_engine_conditions: Si incluir la sección «Condiciones del motor»
        """
        self.include_tables: bool = include_tables
        self.include_views: bool = include_views
        self.include_procedures: bool = include_procedures
        self.include_functions: bool = include_functions
        self.include_storage: bool = include_storage
        self.table_section_flags: list[bool] = table_section_flags
        self.view_section_flags: list[bool] = view_section_flags
        self.include_diagrams: bool = include_diagrams
        self.template_path: Path | None = template_path
        self.diagram_options: dict[str, Any] = diagram_options or {}
        self.include_database_info: bool = include_database_info
        self.database_info_flags: list[bool] = database_info_flags or [False, False]
        self.include_columns_charset: bool = include_columns_charset
        self.include_engine_conditions: bool = include_engine_conditions


class WordGenerator:
    """Clase para generar documentación en formato Word"""

    SECTION_PARAMETROS: str = "Parámetros"
    SECTION_CHARSET_COLLATION: str = "Charset/Collation de Columnas"

    def __init__(self, database: str, headers: HeadersConfig, table_style: str = "Table Grid"):
        self.logger: logging.Logger = logging.getLogger(__name__)
        self.database: str = database
        self.headers: HeadersConfig = dict(headers)  # copia: la sesión comparte el suyo entre formatos (A-12)
        self.headers.setdefault("UNIQUE", ["Nombre Restricción", "Campo"])
        self.table_style: str = table_style
        # (documento, estilo resuelto): el estilo de tabla se resuelve una vez por documento (P-02)
        self._table_style_cache: tuple[Document, str | None] | None = None

    def generate_document(
        self,
        tables: list[tuple[Any, ...]],
        views: list[tuple[Any, ...]],
        routines: list[tuple[Any, ...]],
        data_provider: DocumentationManagerPort,
        output_target: Path,
        print_config: dict[str, Any] | None = None,
        graph_generator: GraphvizRelationshipGraphExt | None = None,
    ) -> None:
        """Genera el documento Word completo con tablas y vistas.

        Args:
            tables: lista de tablas.
            views: lista de vistas.
            data_provider: Proveedor de metadatos de base de datos.
            output_target: Ruta de salida del .docx.
            print_config: Configuración unificada de secciones y gráficos.
        """
        self.logger.info(f"🟢 Iniciando generación de documentación Word para base de datos: {self.database}")
        try:
            normalized_config: dict[str, Any] = PrintConfigManager.normalize(
                print_config or getattr(data_provider, "imprimir_config", {})
            )
            resolved: dict[str, Any] = PrintConfigManager.resolve_for_word(normalized_config)
            include_tables: bool = bool(resolved["include_tables"])
            include_views: bool = bool(resolved["include_views"])
            include_procedures: bool = bool(resolved["include_procedures"])
            include_functions: bool = bool(resolved["include_functions"])
            include_storage: bool = bool(resolved["include_storage"])
            include_database_info: bool = bool(resolved.get("include_database_info", False))
            table_section_flags: list[bool] = resolved["table_section_flags"]
            view_section_flags: list[bool] = resolved["view_section_flags"]
            template_path: Path | None = resolved["template_path"]
            tables_per_document: int = int(resolved["tables_per_document"])
            include_diagrams: bool = bool(resolved["include_diagrams"])
            graph_options: dict[str, Any] = resolved["graph_options"]
            database_info_flags: list[bool] = resolved.get("database_info_flags", [False, False])

            self.logger.debug(
                f"⚙️  Configuración Word resuelta: include_diagrams={include_diagrams}, "
                f"template={template_path}, tables_per_document={tables_per_document}, "
                f"include_database_info={include_database_info}, database_info_flags={database_info_flags}"
            )

            # Diagnóstico: verificar si la información de BD está deshabilitada
            if not include_database_info:
                self.logger.info(
                    "ℹ️  La información de la base de datos NO se incluirá en el documento. "
                    "Si desea incluirla, configure [imprimir.info_database] en el archivo TOML con imprimir_info_database = true"
                )

            tables_for_chunks: list[tuple[Any, ...]] = tables if include_tables else []
            table_chunks: list[list[tuple[Any, ...]]] = self._chunk_tables(tables_for_chunks, tables_per_document)
            if not table_chunks:
                table_chunks = [[]]

            resolved_graph_generator: GraphvizRelationshipGraphExt | None = (
                graph_generator if include_diagrams else None
            )
            if include_diagrams and resolved_graph_generator is None:
                self.logger.debug("🟢 Inicializando generador de grafos para diagramas")
                resolved_graph_generator = self._build_graph_generator(data_provider, graph_options)
            elif resolved_graph_generator is not None:
                self.logger.debug("♻️ Reutilizando generador de grafos compartido para diagramas Word")

            # Configuración de documentos
            doc_config: DocumentChunkConfig = DocumentChunkConfig(
                include_tables=include_tables,
                include_views=include_views,
                include_procedures=include_procedures,
                include_functions=include_functions,
                include_storage=include_storage,
                table_section_flags=table_section_flags,
                view_section_flags=view_section_flags,
                include_diagrams=include_diagrams,
                template_path=template_path,
                diagram_options=graph_options,
                include_database_info=include_database_info,
                database_info_flags=database_info_flags,
                include_columns_charset=resolved.get("include_columns_charset", False),
                include_engine_conditions=bool(resolved.get("include_engine_conditions", False)),
            )

            total_chunks: int = len(table_chunks)
            for idx, table_chunk in enumerate(table_chunks, start=1):
                self.logger.info(f"📄 Generando documento Word {idx}/{total_chunks}")
                self._generate_single_document_chunk(
                    idx=idx,
                    total_chunks=total_chunks,
                    all_tables=tables_for_chunks,
                    table_chunk=table_chunk,
                    views=views,
                    routines=routines,
                    data_provider=data_provider,
                    output_file=output_target,
                    config=doc_config,
                    graph_generator=resolved_graph_generator,
                )

            self.logger.info(f"✅ Generación Word finalizada: {total_chunks} documento(s)")
        finally:
            self._table_style_cache = None

    def _generate_single_document_chunk(
        self,
        idx: int,
        total_chunks: int,
        all_tables: list[tuple[Any, ...]],
        table_chunk: list[tuple[Any, ...]],
        views: list[tuple[Any, ...]],
        routines: list[tuple[Any, ...]],
        data_provider: DocumentationManagerPort,
        output_file: Path,
        config: DocumentChunkConfig,
        graph_generator: GraphvizRelationshipGraphExt | None,
    ) -> None:
        """Genera y guarda un documento Word para un chunk de tablas.

        Args:
            idx: Índice del chunk actual
            total_chunks: Total de chunks a generar
            table_chunk: Tabla(s) del chunk actual
            views: lista de vistas
            routines: lista de rutinas
            data_provider: Proveedor de metadatos
            output_file: Ruta de salida
            config: Configuración del documento (encapsula 10 parámetros)
            graph_generator: Generador de grafos opcional
        """
        try:
            document: Document = self._initialize_document(config.template_path)
            self._configure_document_orientation(document, config.template_path)
            document.add_heading(safe_text(f"Documentación de la Base de Datos - {self.database}"), 0)
            if idx == 1:
                if config.include_diagrams:
                    self._add_diagram_legend_section(document=document)
                self._add_inventory_overview(
                    document=document,
                    tables=all_tables,
                    views=views if config.include_views else [],
                    routines=routines if (config.include_procedures or config.include_functions) else [],
                    include_storage=config.include_storage,
                    data_provider=data_provider,
                    include_procedures=config.include_procedures,
                    include_functions=config.include_functions,
                )

            self._add_tables_content(
                document=document,
                table_chunk=table_chunk,
                data_provider=data_provider,
                table_section_flags=config.table_section_flags,
                include_tables=config.include_tables,
                include_diagrams=config.include_diagrams,
                graph_generator=graph_generator,
                diagram_options=config.diagram_options,
                include_columns_charset=config.include_columns_charset,
            )

            self._add_views_content(
                document=document,
                views=views,
                data_provider=data_provider,
                view_section_flags=config.view_section_flags,
                include_views=config.include_views,
                idx=idx,
                total_chunks=total_chunks,
                include_columns_charset=config.include_columns_charset,
            )

            self._add_routines_content(
                document=document,
                routines=routines,
                data_provider=data_provider,
                include_procedures=config.include_procedures,
                include_functions=config.include_functions,
                idx=idx,
                total_chunks=total_chunks,
            )

            if config.include_database_info and idx == total_chunks:
                self._add_database_info_section(
                    document=document,
                    data_provider=data_provider,
                    database_info_flags=config.database_info_flags,
                )

            if config.include_storage and idx == total_chunks:
                self._add_storage_inventory_section(document=document, data_provider=data_provider)

            if config.include_engine_conditions and idx == total_chunks:
                self._add_engine_conditions_section(document=document, data_provider=data_provider)

            target_file: Path = self._build_output_file_for_chunk(output_file, idx, total_chunks)
            document.save(str(target_file))
            self.logger.info(f"✅ Documento Word generado: {target_file}")
        except Exception as chunk_error:
            chunk_error.add_note(f"Documento Word {idx}/{total_chunks}")
            raise

    def _add_inventory_overview(
        self,
        *,
        document: Document,
        tables: list[tuple[Any, ...]],
        views: list[tuple[Any, ...]],
        routines: list[tuple[Any, ...]],
        include_storage: bool,
        data_provider: DocumentationManagerPort,
        include_procedures: bool,
        include_functions: bool,
    ) -> None:
        """Agrega un resumen inicial con conteos del inventario."""
        filtered_routines: list[tuple[Any, ...]] = GeneratorRoutineRuntime.filter_by_flags(
            routines,
            include_procedures=include_procedures,
            include_functions=include_functions,
            include_non_procedure_as_function=True,
        )
        summary_rows: list[tuple[str, int]] = GeneratorInventoryRuntime.build_summary_rows_from_entities(
            tables=tables,
            views=views,
            routines=filtered_routines,
            include_storage=include_storage,
            data_provider=data_provider,
            include_routines=True,
        )

        self._add_table(
            document=document,
            title="Resumen de inventario",
            headers=["Sección", "Total"],
            data=[[label, str(count)] for label, count in summary_rows],
            right_align_indices=[1],
        )

    def _add_diagram_legend_section(self, *, document: Document) -> None:
        """Agrega una leyenda visual genérica para interpretar diagramas relacionales."""
        legend_payload: dict[str, Any] = build_diagram_legend_payload()
        self._add_table(
            document=document,
            title=str(legend_payload.get("title", "Leyenda visual")),
            headers=["Categoría", "Elemento", "Descripción"],
            data=build_diagram_legend_rows(legend_payload),
        )

        for note in legend_payload.get("notes", []):
            document.add_paragraph(safe_text(note))
        document.add_paragraph("")

    def _configure_document_orientation(self, document: Document, template_path: Path | None) -> None:
        """Configura la orientación del documento según la plantilla."""
        if template_path is None:
            self._configure_landscape(document=document, apply_to_all_sections=True)
        else:
            self.logger.debug("📄 Se respeta la orientación definida en la plantilla Word")

    def _add_tables_content(
        self,
        document: Document,
        table_chunk: list[tuple[Any, ...]],
        data_provider: DocumentationManagerPort,
        table_section_flags: list[bool],
        include_tables: bool,
        include_diagrams: bool,
        graph_generator: GraphvizRelationshipGraphExt | None,
        diagram_options: dict[str, Any],
        include_columns_charset: bool = False,
    ) -> None:
        """Agrega el contenido de tablas al documento."""
        if include_tables and table_chunk:
            if include_diagrams and graph_generator is not None:
                graph_generator.prefetch(
                    self._diagram_render(graph_generator, diagram_options), [row[0] for row in table_chunk]
                )
            document.add_heading("Tablas", level=1)
            for row in table_chunk:
                tabla, comentario, charset_collation = GeneratorTableRuntime.extract_table_row_data(row)
                self._add_table_section(
                    document=document,
                    tabla=tabla,
                    comentario=comentario,
                    charset_collation=charset_collation,
                    data_provider=data_provider,
                    section_flags=table_section_flags,
                    include_table_diagrams=include_diagrams,
                    graph_generator=graph_generator,
                    diagram_options=diagram_options,
                    include_columns_charset=include_columns_charset,
                )

    def _add_views_content(
        self,
        document: Document,
        views: list[tuple[Any, ...]],
        data_provider: DocumentationManagerPort,
        view_section_flags: list[bool],
        include_views: bool,
        idx: int,
        total_chunks: int,
        include_columns_charset: bool = False,
    ) -> None:
        """Agrega el contenido de vistas al documento."""
        if include_views and views and idx == total_chunks:
            document.add_heading("Vistas", level=1)
            for vista, comentario in views:
                self._add_view_section(
                    document,
                    vista,
                    comentario,
                    data_provider,
                    view_section_flags,
                    include_columns_charset,
                )

    def _add_routines_content(
        self,
        document: Document,
        routines: list[tuple[Any, ...]],
        data_provider: DocumentationManagerPort,
        include_procedures: bool,
        include_functions: bool,
        idx: int,
        total_chunks: int,
    ) -> None:
        """Agrega el contenido de rutinas al documento."""
        if routines and idx == total_chunks and (include_procedures or include_functions):
            self._add_routines_sections(
                document=document,
                routines=routines,
                data_provider=data_provider,
                include_procedures=include_procedures,
                include_functions=include_functions,
                include_ddl=True,
            )

    def _initialize_document(self, template_path: Path | None) -> Document:
        """Documento en blanco o desde la plantilla Word configurada.

        Raises:
            DocumentationConfigError: La plantilla no existe o no es un fichero.
        """
        if template_path is None:
            self.logger.debug("🟢 Inicializando documento Word sin plantilla")
            return load_document()

        resolved_template_path: Path = template_path.expanduser().resolve()
        if not resolved_template_path.is_file():
            raise DocumentationConfigError(
                f"Plantilla Word no encontrada o no es un fichero: {resolved_template_path}", operation="DOCUMENTATION"
            )
        self.logger.info(f"📄 Cargando plantilla Word: {resolved_template_path}")
        return load_document(str(resolved_template_path))

    def _chunk_tables(self, tables: list[tuple[Any, ...]], tables_per_document: int) -> list[list[tuple[Any, ...]]]:
        """Divide tablas en lotes para crear múltiples documentos."""
        if not tables:
            return []

        chunk_size = tables_per_document if tables_per_document > 0 else 50
        return [tables[i : i + chunk_size] for i in range(0, len(tables), chunk_size)]

    def _build_output_file_for_chunk(self, output_file: Path, chunk_index: int, total_chunks: int) -> Path:
        """Construye nombre de salida para cada documento segmentado."""
        if total_chunks <= 1:
            return output_file
        return output_file.with_name(f"{output_file.stem}_part{chunk_index}{output_file.suffix}")

    def _add_table_section(
        self,
        document: Document,
        tabla: str,
        comentario: str,
        data_provider: DocumentationManagerPort,
        section_flags: list[bool],
        charset_collation: str | None = None,
        include_table_diagrams: bool = False,
        graph_generator: GraphvizRelationshipGraphExt | None = None,
        diagram_options: dict[str, Any] | None = None,
        include_columns_charset: bool = False,
    ) -> None:
        """Agrega una sección completa para una tabla."""
        document.add_page_break()
        document.add_heading(safe_text(f"Tabla: {tabla}"), level=1)

        # Comentario con etiqueta en negrita
        p = document.add_paragraph()
        p.add_run("Comentario:").bold = True
        p.add_run(safe_text(f" {comentario if comentario else ''}"))

        # Charset & Collation con etiqueta en negrita
        if charset_collation and str(charset_collation).strip():
            p = document.add_paragraph()
            p.add_run("Charset & Collation:").bold = True
            p.add_run(safe_text(f" {charset_collation}"))

        secciones = [
            (0, lambda: self._add_ddl_section(document, tabla, data_provider)),
            (
                1,
                lambda: self._add_columns_section(document, tabla, data_provider, include_columns_charset),
            ),
            (2, lambda: self._add_primary_keys_section(document, tabla, data_provider)),
            (3, lambda: self._add_foreign_keys_section(document, tabla, data_provider)),
            (4, lambda: self._add_unique_constraints_section(document, tabla, data_provider)),
            (5, lambda: self._add_indices_section(document, tabla, data_provider)),
        ]

        for idx, metodo in secciones:
            if section_flags[idx]:
                metodo()

        # Solo tablas: insertar diagrama con salto de página
        if include_table_diagrams and graph_generator is not None:
            self._add_table_diagram_page(
                document=document,
                tabla=tabla,
                graph_generator=graph_generator,
                diagram_options=diagram_options or {},
            )

    def _build_graph_generator(self, data_provider: Any, options: dict[str, Any]) -> GraphvizRelationshipGraphExt:
        """Crea el generador de grafos cuando el orquestador no ha pasado uno."""
        return build_graph_generator_from_options(data_provider.db_manager, options)

    @staticmethod
    def _diagram_render(
        graph_generator: GraphvizRelationshipGraphExt, diagram_options: dict[str, Any]
    ) -> Callable[[str], object]:
        """La llamada de render de un diagrama de tabla (la misma en la precarga y en la página)."""
        fmt: str = str(diagram_options.get("format", "png")).lower()
        common: dict[str, Any] = {
            "format": "png" if fmt == "svg" else fmt,
            "max_depth": int(diagram_options.get("max_depth", 1)),
            "direction": str(diagram_options.get("direction", "both")),
        }
        if bool(diagram_options.get("images_paginated", False)):
            max_subnodes: int = int(diagram_options.get("max_subnodes", 10))
            return lambda table_name: graph_generator.pipe_paginated_graph_ext(
                table_name=table_name, max_subnodes=max_subnodes, **common
            )
        return lambda table_name: graph_generator.pipe_single_table_graph_ext(table_name=table_name, **common)

    def _add_table_diagram_page(
        self,
        document: Document,
        tabla: str,
        graph_generator: GraphvizRelationshipGraphExt,
        diagram_options: dict[str, Any],
    ) -> None:
        """Inserta el diagrama de una tabla: una página, o una por bloque de ``max_subnodes`` si ``images_paginated``.

        Los PNG salen de Graphviz en memoria (precargados en paralelo por documento en ``_add_tables_content``).
        """
        self.logger.debug(f"🖼️ Iniciando generación de diagrama Word para tabla: {tabla}")
        graph_document: Any | None = self._build_diagram_document(
            tabla=tabla,
            graph_generator=graph_generator,
            diagram_options=diagram_options,
        )
        diagram_summary: dict[str, Any] = self._build_diagram_summary_payload(
            tabla=tabla,
            graph_generator=graph_generator,
            diagram_options=diagram_options,
            document=graph_document,
        )
        try:
            rendered: object = self._diagram_render(graph_generator, diagram_options)(tabla)
        except (OSError, RuntimeError) as e:
            document.add_page_break()
            document.add_heading(safe_text(f"Diagrama de relaciones: {tabla}"), level=2)
            document.add_paragraph(safe_text(f"⚠️ No se pudo generar el diagrama: {e}"))
            return

        pages: list[bytes] = list(rendered) if isinstance(rendered, list) else [cast(bytes, rendered)]
        paginated: bool = isinstance(rendered, list)
        for page_idx, image_bytes in enumerate(pages, start=1):
            document.add_page_break()
            title = f"Diagrama de relaciones: {tabla}" + (f" (Página {page_idx})" if paginated else "")
            title_paragraph: Paragraph = document.add_heading(safe_text(title), level=2)
            self._add_picture_from_bytes(document=document, image_bytes=image_bytes, title_paragraph=title_paragraph)
            self._add_diagram_summary_paragraph(document=document, summary_payload=diagram_summary)
        self.logger.debug(f"🖼️  Diagrama insertado en Word para {tabla}: {len(pages)} imagen(es)")

    def _build_diagram_document(
        self, tabla: str, graph_generator: GraphvizRelationshipGraphExt, diagram_options: dict[str, Any]
    ) -> Any | None:
        """Construye una vez el GraphDocument para reutilizarlo entre resumen y render."""
        if not hasattr(graph_generator, "build_graph_document"):
            return None

        try:
            return graph_generator.build_graph_document(
                table_name=tabla,
                max_depth=int(diagram_options.get("max_depth", 1)),
                direction=str(diagram_options.get("direction", "both")),
            )
        except (OSError, RuntimeError) as error:
            self.logger.debug(f"⚠️ No se pudo construir el resumen de niveles para {tabla}: {error}")
            return None

    def _build_diagram_summary_payload(
        self,
        tabla: str,
        graph_generator: GraphvizRelationshipGraphExt,
        diagram_options: dict[str, Any],
        document: Any | None = None,
    ) -> dict[str, Any]:
        """Construye el resumen estructurado de niveles para Word."""
        graph_document: Any | None = document or self._build_diagram_document(
            tabla=tabla,
            graph_generator=graph_generator,
            diagram_options=diagram_options,
        )
        if graph_document is None or not bool(diagram_options.get("summary", {}).get("enabled", True)):
            return {}

        visible_outgoing_levels = max(
            0,
            int(graph_document.total_outgoing_levels) - int(graph_document.hidden_levels.outgoing_hidden_levels),
        )
        visible_incoming_levels = max(
            0,
            int(graph_document.total_incoming_levels) - int(graph_document.hidden_levels.incoming_hidden_levels),
        )
        payload = build_diagram_summary_payload(
            max_depth=int(graph_document.max_depth),
            total_outgoing_levels=int(graph_document.total_outgoing_levels),
            total_incoming_levels=int(graph_document.total_incoming_levels),
            visible_outgoing_levels=visible_outgoing_levels,
            visible_incoming_levels=visible_incoming_levels,
            hidden_outgoing_levels=int(graph_document.hidden_levels.outgoing_hidden_levels),
            hidden_incoming_levels=int(graph_document.hidden_levels.incoming_hidden_levels),
        )
        payload["root_table"] = tabla
        return payload

    def _add_diagram_summary_paragraph(
        self,
        document: Document,
        summary_payload: dict[str, Any],
    ) -> None:
        """Agrega el resumen de niveles bajo el diagrama en Word."""
        if not summary_payload:
            return

        paragraph: Paragraph = document.add_paragraph()
        paragraph.add_run("Resumen de niveles: ").bold = True
        paragraph.add_run(safe_text(build_diagram_summary_line(summary_payload)))

        if bool(summary_payload.get("has_any_hidden_levels")):
            if bool(summary_payload.get("has_hidden_outgoing_levels")):
                document.add_paragraph(safe_text(str(summary_payload.get("outgoing_hidden_help", ""))))
            if bool(summary_payload.get("has_hidden_incoming_levels")):
                document.add_paragraph(safe_text(str(summary_payload.get("incoming_hidden_help", ""))))

        for tip in summary_payload.get("navigation_tips", []):
            document.add_paragraph(safe_text(str(tip)))

    def _compute_max_dimensions(self, document: Document, title_paragraph: Paragraph | None = None) -> tuple[int, int]:
        """Calcula el ancho y alto máximos disponibles (en EMU) para una imagen en la página actual.

        Args:
            document: Documento Word activo
            title_paragraph: Párrafo de título a reservar (puede ser None)

        Returns:
            tuple[int, int]: (max_width, max_height) en unidades EMU

        Examples:
            >>> max_w, max_h = generator._compute_max_dimensions(document, title_paragraph)
            >>> max_w > 0 and max_h > 0
            True
        """
        section: Section = document.sections[-1]
        page_width: int = int(section.page_width) if section.page_width is not None else int(Emu(0))
        page_height: int = int(section.page_height) if section.page_height is not None else int(Emu(0))
        left_margin: int = int(section.left_margin) if section.left_margin is not None else 0
        right_margin: int = int(section.right_margin) if section.right_margin is not None else 0
        top_margin: int = int(section.top_margin) if section.top_margin is not None else 0
        bottom_margin: int = int(section.bottom_margin) if section.bottom_margin is not None else 0
        reserved_title_height: int = self._estimate_paragraph_reserved_height_emu(title_paragraph)
        safety_padding = int(Pt(24))
        picture_paragraph_reserved = int(Pt(18))

        max_width: int = page_width - left_margin - right_margin
        max_height: int = (
            page_height
            - top_margin
            - bottom_margin
            - reserved_title_height
            - picture_paragraph_reserved
            - safety_padding
        )
        return max(max_width, int(Pt(72))), max(max_height, int(Pt(72)))

    def _add_picture_from_bytes(
        self,
        document: Document,
        image_bytes: bytes,
        title_paragraph: Paragraph | None = None,
    ) -> None:
        """Inserta imagen desde bytes en memoria ajustándola al área imprimible de la página.

        Variante en memoria de _add_picture_fit_to_page. No requiere archivo en disco.
        Realiza seek(0) entre la lectura de dimensiones y la inserción para reutilizar
        el mismo buffer.

        Args:
            document: Documento Word activo
            image_bytes: Bytes de la imagen (PNG, JPEG, etc.)
            title_paragraph: Párrafo de título ya añadido al documento, usado para calcular
                el espacio vertical a reservar. Si es None se omite la reserva.

        Returns:
            None

        Raises:
            OSError: Si python-docx no puede procesar los bytes como imagen válida

        Examples:
            >>> generator._add_picture_from_bytes(document, png_bytes, title_paragraph)
        """
        max_width, max_height = self._compute_max_dimensions(document, title_paragraph)
        buf = io.BytesIO(image_bytes)
        image = DocxImage.from_file(buf)
        image_width = int(image.width)
        image_height = int(image.height)

        if image_width <= 0 or image_height <= 0:
            buf.seek(0)
            document.add_picture(buf, width=Emu(max_width))
            return

        width_ratio: float = max_width / image_width
        height_ratio: float = max_height / image_height
        scale: float = min(width_ratio, height_ratio, 1.0) * 0.98

        scaled_width = Emu(max(1, int(image_width * scale)))
        scaled_height = Emu(max(1, int(image_height * scale)))
        buf.seek(0)
        document.add_picture(buf, width=scaled_width, height=scaled_height)

    def _estimate_paragraph_reserved_height_emu(self, paragraph: Paragraph | None) -> int:
        """Estima espacio vertical a reservar para un título en la página de imagen."""
        if paragraph is None:
            return 0

        run_font_size = next((run.font.size for run in paragraph.runs if run.font.size is not None), None)
        style_font_size = paragraph.style.font.size if paragraph.style is not None else None
        font_size = run_font_size or style_font_size or Pt(16)

        paragraph_format = paragraph.paragraph_format
        space_before_pt = paragraph_format.space_before.pt if paragraph_format.space_before is not None else 0.0
        space_after_pt = paragraph_format.space_after.pt if paragraph_format.space_after is not None else 0.0

        reserved_points: float = (font_size.pt * 1.8) + float(space_before_pt) + float(space_after_pt) + 8.0
        return int(Pt(reserved_points))

    def _configure_landscape(self, document: Document, apply_to_all_sections: bool = False) -> None:
        """Configura la página en orientación apaisada sin invertir secciones ya horizontales."""
        sections = document.sections if apply_to_all_sections else [document.sections[-1]]

        for section in sections:
            if section.orientation == WD_ORIENT.LANDSCAPE:
                continue

            new_width, new_height = section.page_height, section.page_width
            section.orientation = WD_ORIENT.LANDSCAPE
            section.page_width = new_width
            section.page_height = new_height

    def _add_view_section(
        self,
        document: Document,
        vista: str,
        comentario: str,
        data_provider: DocumentationManagerPort,
        section_flags: list[bool],
        include_columns_charset: bool = False,
    ) -> None:
        """Agrega una sección para una vista (solo DDL y Columnas)"""
        document.add_page_break()
        document.add_heading(safe_text(f"Vista: {vista}"), level=2)
        document.add_paragraph(safe_text(f"Comentario: {comentario if comentario else ''}"))

        # Secciones para vistas: [DDL, Columnas]
        if len(section_flags) > 0 and section_flags[0]:
            try:
                self._add_ddl_section(document, vista, data_provider, is_view=True)
            except DatabaseException:
                document.add_paragraph("⚠️ No se pudo obtener el DDL de la vista")

        if len(section_flags) > 1 and section_flags[1]:
            try:
                self._add_columns_section(document, vista, data_provider, include_columns_charset)
            except DatabaseException:
                document.add_paragraph("⚠️ No se pudieron obtener las columnas de la vista")

    def _add_routines_sections(
        self,
        document: Document,
        routines: list[tuple[Any, ...]],
        data_provider: DocumentationManagerPort,
        include_procedures: bool,
        include_functions: bool,
        include_ddl: bool,
    ) -> None:
        """Agrega secciones de procedures, funciones y otras rutinas al documento."""
        procedures, functions = GeneratorRoutineRuntime.split_by_type(routines)

        if include_procedures and procedures:
            self._add_routine_type_section(
                document=document,
                routines=procedures,
                routine_type="Procedures",
                data_provider=data_provider,
                include_ddl=include_ddl,
            )

        if include_functions and functions:
            self._add_routine_type_section(
                document=document,
                routines=functions,
                routine_type="Funciones",
                data_provider=data_provider,
                include_ddl=include_ddl,
            )

        self._add_other_routines_section(
            document=document,
            routines=routines,
            data_provider=data_provider,
            include_ddl=include_ddl,
        )

    def _add_routine_type_section(
        self,
        document: Document,
        routines: list[tuple[Any, ...]],
        routine_type: str,
        data_provider: DocumentationManagerPort,
        include_ddl: bool,
    ) -> None:
        """Agrega rutinas de un tipo específico (Procedures o Funciones)."""
        document.add_heading(safe_text(routine_type), level=1)
        for routine in routines:
            routine_name, routine_type_normalized, routine_comment = GeneratorRoutineRuntime.normalize_entry(routine)
            self._add_routine_section(
                document=document,
                routine_name=routine_name,
                routine_type=routine_type_normalized,
                comentario=routine_comment,
                data_provider=data_provider,
                include_ddl=include_ddl,
            )

    def _add_other_routines_section(
        self,
        document: Document,
        routines: list[tuple[Any, ...]],
        data_provider: DocumentationManagerPort,
        include_ddl: bool,
    ) -> None:
        """Procesa rutinas que no son PROCEDURE ni FUNCTION."""
        for routine in routines:
            routine_name, routine_type, routine_comment = GeneratorRoutineRuntime.normalize_entry(routine)
            if routine_type in {"PROCEDURE", "FUNCTION"}:
                continue
            self._add_routine_section(
                document=document,
                routine_name=routine_name,
                routine_type=routine_type,
                comentario=routine_comment,
                data_provider=data_provider,
                include_ddl=include_ddl,
            )

    def _add_routine_section(
        self,
        document: Document,
        routine_name: str,
        routine_type: str,
        comentario: str,
        data_provider: DocumentationManagerPort,
        include_ddl: bool,
    ) -> None:
        """Agrega una sección para una rutina (procedure/función)."""
        document.add_page_break()
        document.add_heading(safe_text(f"{routine_type.title()}: {routine_name}"), level=2)
        document.add_paragraph(safe_text(f"Tipo: {routine_type.title()}"))
        document.add_paragraph(safe_text(f"Comentario: {comentario if comentario else ''}"))

        if include_ddl:
            try:
                ddl: str = data_provider.get_routine_ddl(routine_name, routine_type)
                text_ddl: str = ddl if ddl is not None else ""
                document.add_heading("DDL", level=3)
                paragraph: Paragraph = document.add_paragraph()
                run: Run = paragraph.add_run(safe_text(text_ddl))
                run.font.name = "Courier New"
                run.font.size = Pt(10.5)
                paragraph.style = "No Spacing"
                document.add_paragraph("")
            except DatabaseException:
                document.add_paragraph("⚠️ No se pudo obtener el DDL de la rutina")

        self._add_routine_parameters_section(
            document=document,
            routine_name=routine_name,
            routine_type=routine_type,
            data_provider=data_provider,
        )

    def _add_routine_parameters_section(
        self,
        document: Document,
        routine_name: str,
        routine_type: str,
        data_provider: DocumentationManagerPort,
    ) -> None:
        """Agrega la tabla de parámetros de una rutina."""
        try:
            parameters = data_provider.get_routine_parameters(routine_name, routine_type)
        except DatabaseException:
            self._add_empty_section(
                document,
                self.SECTION_PARAMETROS,
                "No se pudieron obtener los parámetros de la rutina.",
            )
            return

        if not parameters:
            self._add_empty_section(document, self.SECTION_PARAMETROS, "No se encontraron parámetros.")
            return

        headers = self.headers.get("PARAMETROS_RUTINA", ["Modo", "Parámetro", "Tipo", "Valor por defecto", "Posición"])
        rows = GeneratorRoutineRuntime.parameter_rows(parameters)
        self._add_table(document, self.SECTION_PARAMETROS, headers, rows)

    def _add_ddl_section(
        self, document: Document, tabla: str, data_provider: DocumentationManagerPort, is_view: bool = False
    ) -> None:
        """Agrega la sección DDL"""
        ddl: str = data_provider.get_view_ddl(tabla) if is_view else data_provider.get_ddl(tabla)
        text_ddl: str = ddl if ddl is not None else ""

        document.add_heading("DDL", level=2)
        paragraph: Paragraph = document.add_paragraph()
        run: Run = paragraph.add_run(safe_text(text_ddl))
        run.font.name = "Courier New"
        run.font.size = Pt(10.5)
        paragraph.style = "No Spacing"
        document.add_paragraph("")

    def _add_columns_section(
        self,
        document: Document,
        tabla: str,
        data_provider: DocumentationManagerPort,
        include_columns_charset: bool = False,
    ) -> None:
        """Agrega la sección de columnas"""
        columnas = data_provider.get_columns(tabla)
        if not columnas:
            self._add_empty_section(document, "Columnas", "No se encontraron columnas.")
            if include_columns_charset:
                self._add_empty_section(
                    document,
                    self.SECTION_CHARSET_COLLATION,
                    "No hay información de charset/collation disponible.",
                )
            return

        headers = self.headers["COLUMNAS"]

        columnas_procesadas = GeneratorTabularRuntime.process_columns_data(columnas)

        self._add_table(document, "Columnas", headers, columnas_procesadas)

        # Agregar sección de charset/collation si está habilitado
        if include_columns_charset:
            try:
                charset_info = data_provider.get_columns_charset_collation(tabla)
                if charset_info:
                    charset_headers = ["Columna", "Charset", "Collation"]
                    charset_rows = [[row[0], row[1] or "", row[2] or ""] for row in charset_info]
                    self._add_table(document, self.SECTION_CHARSET_COLLATION, charset_headers, charset_rows)
                else:
                    self._add_empty_section(
                        document,
                        self.SECTION_CHARSET_COLLATION,
                        "No hay información de charset/collation disponible.",
                    )
            except DatabaseException as e:
                self.logger.debug(f"⚠️  No se pudo obtener charset/collation de columnas para {tabla}: {e}")
                self._add_empty_section(
                    document,
                    self.SECTION_CHARSET_COLLATION,
                    f"Error obteniendo información: {str(e)}",
                )

    def _add_primary_keys_section(
        self, document: Document, tabla: str, data_provider: DocumentationManagerPort
    ) -> None:
        """Agrega la sección de claves primarias"""
        claves = data_provider.get_primary_keys(tabla)
        if claves:
            self._add_table(document, "Claves Primarias", ["Campo"], claves)
        else:
            self._add_empty_section(document, "Claves Primarias", "No se encontraron claves primarias.")

    def _add_foreign_keys_section(
        self, document: Document, tabla: str, data_provider: DocumentationManagerPort
    ) -> None:
        """Agrega la sección de claves foráneas"""
        claves = data_provider.get_foreign_keys(tabla)
        if claves:
            self._add_table(document, "Relaciones (Claves Foráneas)", self.headers["FK"], claves)
        else:
            self._add_empty_section(document, "Relaciones (Claves Foráneas)", "No se encontraron claves foráneas.")

    def _add_unique_constraints_section(
        self, document: Document, tabla: str, data_provider: DocumentationManagerPort
    ) -> None:
        """Agrega la sección de restricciones únicas"""
        unique_constraints = data_provider.get_unique_constraints(tabla)
        claves = GeneratorTabularRuntime.process_unique_constraints_data(unique_constraints)
        if claves:
            self._add_table(document, "Restricciones Únicas", self.headers["UNIQUE"], claves)
        else:
            self._add_empty_section(document, "Restricciones Únicas", "No se encontraron claves únicas.")

    def _add_indices_section(self, document: Document, tabla: str, data_provider: DocumentationManagerPort) -> None:
        """Agrega la sección de índices"""
        indices = data_provider.get_indices(tabla)
        if indices:
            datos_procesados = GeneratorTabularRuntime.process_indices_data(indices)
            self._add_table(document, "Índices", self.headers["INDICES"], datos_procesados)
        else:
            self._add_empty_section(document, "Índices", "No se encontraron índices.")

    def _add_empty_section(self, document: Document, title: str, message: str) -> None:
        """Agrega título de sección y mensaje cuando no hay resultados."""
        document.add_heading(safe_text(title), level=2)
        document.add_paragraph(safe_text(message))
        document.add_paragraph("")

    def _add_database_info_section(
        self,
        document: Document,
        data_provider: DocumentationManagerPort,
        database_info_flags: list[bool],
    ) -> None:
        """Agrega una sección con información de la base de datos (versión, charset/collation).

        Args:
            document: Documento Word
            data_provider: Proveedor de metadatos (SyncDatabaseManager)
            database_info_flags: [version_flag, charset_collation_flag]
        """
        self.logger.info(f"📚 Agregando sección de información de BD con flags: {database_info_flags}")
        document.add_page_break()
        document.add_heading("Información de la Base de Datos", level=1)

        try:
            info_data: list[list[str]] = GeneratorDatabaseInfoRuntime.collect_database_info_rows(
                data_provider=data_provider,
                database_info_flags=database_info_flags,
                logger=self.logger,
                include_error_rows=True,
            )
            self.__render_database_info_to_document(document, info_data)
        except DatabaseException as error:
            self.logger.exception(f"❌ Error agregando sección de información de BD: {error}")
            self._add_empty_section(
                document=document,
                title="Información de Base de Datos",
                message=f"Error al obtener información: {error}",
            )

    def __render_database_info_to_document(self, document: Document, info_data: list[list[str]]) -> None:
        """Renderiza información de BD al documento.

        Args:
            document: Documento Word
            info_data: Datos a renderizar
        """
        if info_data:
            self._add_table(
                document=document,
                title="Propiedades",
                headers=["Propiedad", "Valor"],
                data=info_data,
            )
        else:
            self._add_empty_section(
                document=document,
                title="Información",
                message="No se configuró información de base de datos para mostrar",
            )

    def _add_engine_conditions_section(self, document: Document, data_provider: DocumentationManagerPort) -> None:
        """Agrega al final la sección «Condiciones del motor» (``EngineReadinessAdvisor``)."""
        section = EngineConditionsSectionBuilder.of(data_provider)
        document.add_page_break()
        document.add_heading("Condiciones del motor", level=1)
        for notice in section.notices:
            document.add_paragraph(safe_text(notice))
        if section.metadata:
            self._add_table(
                document=document,
                title="Verificación",
                headers=["Propiedad", "Valor"],
                data=[list(item) for item in section.metadata],
            )
        if section.summary:
            self._add_table(
                document=document,
                title="Resumen por severidad",
                headers=["Nivel", "Hallazgos"],
                data=[[level, str(count)] for level, count in section.summary],
                right_align_indices=[1],
            )
        if section.rows:
            self._add_table(
                document=document,
                title="Hallazgos",
                headers=list(section.headers),
                data=[list(row) for row in section.rows],
            )

    def _add_storage_inventory_section(self, document: Document, data_provider: DocumentationManagerPort) -> None:
        """Agrega al final un resumen de almacenamiento físico/tablespaces."""
        document.add_page_break()
        document.add_heading("Almacenamiento", level=1)

        try:
            report: dict[str, Any] = data_provider.get_storage_inventory_report()
        except DatabaseException as error:
            self._add_empty_section(
                document=document,
                title="Inventario de almacenamiento",
                message=f"No se pudo obtener la información de almacenamiento: {error}",
            )
            return

        sections: list[dict[str, Any]] = report.get("sections", [])
        summary_rows: list[list[str]] = []
        for section in sections:
            summary_rows.append(
                [
                    str(section.get("title", "")),
                    str(section.get("status", "")),
                    str(len(section.get("rows", []))),
                    str(section.get("message", "")),
                ]
            )

        if summary_rows:
            self._add_table(
                document=document,
                title="Resumen",
                headers=["Consulta", "Estado", "Filas", "Mensaje"],
                data=summary_rows,
                right_align_indices=[2],
            )

        for section in sections:
            title: str = str(section.get("title", "Consulta"))
            headers: list[str] = [str(h) for h in section.get("headers", [])]
            rows: list[list[Any]] = section.get("rows", [])
            if not headers and rows:
                max_cols: int = max(len(row) for row in rows)
                headers = [f"Columna {idx}" for idx in range(1, max_cols + 1)]

            if rows:
                numeric_columns: list[int] = [int(idx) for idx in section.get("numeric_columns", [])]
                self._add_table(
                    document=document,
                    title=title,
                    headers=headers,
                    data=rows,
                    right_align_indices=numeric_columns,
                )
            else:
                self._add_empty_section(
                    document=document,
                    title=title,
                    message=str(section.get("message", "Sin datos")),
                )

    def _add_table(
        self,
        document: Document,
        title: str,
        headers: list[str],
        data: list[Any],
        right_align_indices: list[int] | None = None,
    ) -> None:
        """Agrega una tabla al documento Word"""
        align_right_set: set[int] = set(right_align_indices or [])
        document.add_heading(safe_text(title), level=2)
        table: Table = document.add_table(rows=1, cols=len(headers))
        self._apply_table_style(table=table, document=document)
        self._repeat_header(table.rows[0])

        # Agregar encabezados
        hdr_cells = table.rows[0].cells
        for i, header in enumerate(headers):
            hdr_cells[i].text = safe_text(header)

        # Agregar datos
        for row_data in data:
            row_cells = table.add_row().cells
            max_cols = min(len(headers), len(row_data))
            for i in range(max_cols):
                val = row_data[i]
                row_cells[i].text = safe_text(str(val) if val is not None else "")
                if i in align_right_set:
                    for paragraph in row_cells[i].paragraphs:
                        paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT

        document.add_paragraph("")

    def _apply_table_style(self, table: Table, document: Document) -> None:
        """Aplica el estilo de tabla configurado; si el documento no lo tiene, "Table Grid" o "Normal Table".

        El estilo se resuelve una vez por documento (P-02: recorrer los estilos en cada tabla era el 43 % del tiempo
        de Word sin diagramas) y se reutiliza en las demás tablas.
        """
        cached = self._table_style_cache
        if cached is not None and cached[0] is document:
            if cached[1] is not None:
                table.style = cached[1]
            return
        resolved: str | None = self._resolve_table_style(table, document)
        self._table_style_cache = (document, resolved)

    def _resolve_table_style(self, table: Table, document: Document) -> str | None:
        """Prueba el estilo configurado y los de respaldo sobre ``table`` y devuelve el que se aplicó (o ``None``)."""
        preferred_style: str = self.table_style
        fallback_styles: list[str] = ["Table Grid", "Normal Table"]

        def normalize_style_name(style_name: str) -> str:
            return " ".join(style_name.replace("–", "-").replace("—", "-").split()).casefold()

        normalized_available: dict[str, str] = {
            normalize_style_name(str(style.name)): str(style.name)
            for style in document.styles
            if style.type is not None and style.name
        }

        resolved_preferred_style: str = normalized_available.get(normalize_style_name(preferred_style), preferred_style)
        try:
            table.style = resolved_preferred_style
            return resolved_preferred_style
        except KeyError:
            pass

        self.logger.warning(f"⚠️ Estilo de tabla '{preferred_style}' no disponible en el documento. Aplicando fallback.")
        for fallback_style in fallback_styles:
            resolved_style: str = normalized_available.get(normalize_style_name(fallback_style), fallback_style)
            try:
                table.style = resolved_style
                self.logger.info(f"🟢 Usando estilo de tabla de respaldo: {resolved_style}")
                return resolved_style
            except KeyError:
                continue

        self.logger.warning("⚠️ No se encontró un estilo de tabla de respaldo. Se usa el estilo por defecto de Word.")
        return None

    def _repeat_header(self, row: _Row) -> None:
        """Configura la repetición de cabecera en tablas Word"""
        tr = row._tr
        tr_pr = tr.get_or_add_trPr()
        tbl_header = OxmlElement("w:tblHeader")
        tbl_header.set(qn("w:val"), "true")
        tr_pr.append(tbl_header)
