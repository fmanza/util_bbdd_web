"""Paquete interno."""
