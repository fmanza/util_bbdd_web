"""Metadatos de Oracle (ADR-003): ``catalog`` (``CatalogDialect`` para la lectura por lotes) y SQL puntual.

No re-exporta nada: se importa cada submódulo (``util_bbdd.metadata.oracle.catalog``…).
"""
