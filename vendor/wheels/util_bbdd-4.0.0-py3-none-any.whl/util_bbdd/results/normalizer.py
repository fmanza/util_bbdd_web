"""Normalización homogénea de resultados de cursores sync/async."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from .types import Row, RowOrNone, Rows


class ResultNormalizer:
    """Convierte resultados crudos de drivers a contrato estable Row/Rows."""

    @staticmethod
    def normalize_one(result: Any) -> RowOrNone:
        """Normaliza resultado de fetchone().

        Args:
            result: Fila del driver (tupla, lista, fila de SQLAlchemy…) o ``None``.

        Returns:
            La fila como tupla, o ``None`` si no hay fila.
        """
        if result is None:
            return None
        return ResultNormalizer._as_row(result)

    @staticmethod
    def normalize_many(result: Any) -> Rows:
        """Normaliza resultado de fetchall() a lista materializada de filas.

        Args:
            result: Resultado del driver: lista, tupla o iterable de filas, una fila suelta o ``None``.

        Returns:
            Lista de filas (tuplas); ``[]`` si ``result`` es ``None``.
        """
        if result is None:
            return []

        if isinstance(result, list):
            return ResultNormalizer._normalize_from_sequence(result)

        if isinstance(result, tuple):
            return ResultNormalizer._normalize_from_sequence(list(result))

        if isinstance(result, Iterable) and not isinstance(result, (str, bytes, bytearray, memoryview, dict)):
            return ResultNormalizer._normalize_from_sequence(list(result))

        return [ResultNormalizer._as_row(result)]

    @staticmethod
    def _normalize_from_sequence(values: list[Any]) -> Rows:
        if not values:
            return []

        first = values[0]
        if ResultNormalizer._is_row_sequence(first):
            return [ResultNormalizer._as_row(value) for value in values]

        # Caso atípico: colección plana (p. ej. [1, 2, 3]) tratada como fila única.
        return [ResultNormalizer._as_row(values)]

    @staticmethod
    def _is_row_sequence(value: Any) -> bool:
        return isinstance(value, (list, tuple)) or ResultNormalizer._is_driver_row(value)

    @staticmethod
    def _is_driver_row(value: Any) -> bool:
        """Fila de driver que no es ``tuple`` (``pyodbc.Row``, también la de aioodbc; ``sqlite3.Row``): secuencia indexable.

        Hasta v1.0.0 se envolvía en otra tupla: ``((1, 'a'),)`` en ``execute_custom_one`` y una sola «fila» con todas las
        filas en ``execute_custom_many`` (hotfix 1.1.0). Texto, bytes y mapeos siguen siendo un único valor.
        """
        if isinstance(value, (str, bytes, bytearray, memoryview, Mapping)):
            return False
        return hasattr(value, "__len__") and hasattr(value, "__getitem__")  # pyodbc.Row no define __iter__

    @staticmethod
    def _as_row(value: Any) -> Row:
        if isinstance(value, tuple):
            return value
        if isinstance(value, list) or ResultNormalizer._is_driver_row(value):
            return tuple(value)
        return (value,)
